# Fiona Zhao Portfolio

这是 Fiona 的 AI + 新媒体 作品集网页，使用 Next.js 构建，可部署至 Vercel。

包含项目：
- 联通广告语
- 建筑海报
- 东方博物之门纪录片
- 微电影《石记》
