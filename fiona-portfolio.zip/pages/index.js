export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 px-6 py-10 font-sans">
      <div className="max-w-3xl mx-auto">
        <img
          src="/avatar.jpg"
          alt="Fiona Zhao"
          className="w-32 h-32 rounded-full mx-auto shadow-lg"
        />
        <h1 className="text-3xl text-center font-bold mt-6">Fiona Zhao Portfolio</h1>
        <p className="text-center text-gray-600 mt-2">
          网络与新媒体方向在校生，热衷于数据可视化与交互产品
        </p>

        <section className="mt-10">
          <h2 className="text-2xl font-semibold mb-4">🧰 项目展示</h2>
          <ul className="space-y-4">
            <li className="border rounded-lg p-4 shadow hover:shadow-md transition">
              <h3 className="font-bold">📡 联通广告语：连接未来，与沃同行</h3>
              <p className="text-sm text-gray-700">品牌传播创意脚本项目，聚焦科技感与传播力结合。</p>
            </li>
            <li className="border rounded-lg p-4 shadow hover:shadow-md transition">
              <h3 className="font-bold">🏙️ 建筑海报组图</h3>
              <p className="text-sm text-gray-700">视觉设计作品集，展示图文融合与空间叙事。</p>
            </li>
            <li className="border rounded-lg p-4 shadow hover:shadow-md transition">
              <h3 className="font-bold">🎬 纪录片《东方博物之门》</h3>
              <a
                href="https://www.bilibili.com/opus/1074091829487468545"
                className="text-blue-600 underline text-sm"
                target="_blank"
              >
                点此观看 Bilibili
              </a>
              <p className="text-sm text-gray-700 mt-1">中法建交60周年特别项目，担任采访翻译与字幕撰写。</p>
            </li>
            <li className="border rounded-lg p-4 shadow hover:shadow-md transition">
              <h3 className="font-bold">🎞️ 微电影《石记》</h3>
              <p className="text-sm text-gray-700">自编自导剧本创作，风格致敬《漫长的季节》，关注都市记忆与人文情感。</p>
            </li>
          </ul>
        </section>
      </div>
    </main>
  );
}
